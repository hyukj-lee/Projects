Cheonan-si administrative dong boundary only. Source: BND_ADM_DONG_PG, BASE_DATE 20250630. CRS is original KGD2002 Central Belt in meters.
